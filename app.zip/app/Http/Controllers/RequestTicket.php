<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use Image;
class RequestTicket extends Controller
{
    function ticketData(Request $req)
  {
    //form validation
    $this->validate($req, [
      'issuetitle' => 'required|max:50',
      'describeissue' => 'required|max:200',
  ]);
     // Get the currently authenticated user...
  $user = Auth::user();


    $curl = curl_init();
    curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://cc.codeconspirators.com/rest/13/kpylyymjqouoe0v2/tasks.task.add',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',

      CURLOPT_POSTFIELDS => '{"fields":{
        "TITLE":"' . $req->issuetitle . '",
        "DESCRIPTION":"'.$req->describeissue .'",
        "UF_AUTO_457307501852":"'.$req->projectname.'",
        "UF_AUTO_226162412347":"'.$user->email.'",
         "UF_AUTO_467618799502":"'.$req->flexRadioDefault.'",
        "UF_AUTO_855501359250":"'.$req->issueURL.'",
        "RESPONSIBLE_ID":13,
        "GROUP_ID":34

    }}',
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'Cookie: BITRIX_SM_SALE_UID=0; qmb=.'
      ),
    ));

    $response = curl_exec($curl);
    
    $task_resp = json_decode($response);
    //dd($task_resp->result->task->id);
    $id =$task_resp->result->task->id;

    $name = $req->img->getClientOriginalName();
    curl_close($curl);

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, 'https://cc.codeconspirators.com/rest/13/kpylyymjqouoe0v2/task.item.addfile.xml');
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, array( 
        'TASK_ID' => $id, 
        'FILE[NAME]' => "'.$name.'", 
        'FILE[CONTENT]' => base64_encode(file_get_contents($req->img)) 
    ));
    
    $out = curl_exec($curl);
  //  dd($out);
    curl_close($curl);    

        return back()->withStatus(__('Thank you! Your ticket submitted successfully.')); 
  }
}
