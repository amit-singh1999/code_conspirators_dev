<?php

namespace App\Http\Controllers;

use DB;
use Hash;
use Mail;

use App\Models\User;
use App\Models\Project;

use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function api_dev(){
        \Artisan::call('route:cache');
        \Artisan::call('route:clear');
        \Artisan::call('config:cache');
        \Artisan::call('config:clear');
        \Artisan::call('key:generate');
        echo "true";
    }
    public function api(){
        $dir = storage_path().'/logs/test.txt';
        //file_put_contents($dir,json_encode($_REQUEST),FILE_APPEND|LOCK_EX);
        $taskId = json_encode($_REQUEST['data']['FIELDS_AFTER']['ID']);

//     $taskId = 98;
        //file_put_contents($dir,$taskId,FILE_APPEND|LOCK_EX);
            
            $curl = curl_init();
            
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://cc.codeconspirators.com/rest/13/kpylyymjqouoe0v2/task.item.getdata",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => '{"id":'.$taskId.'}',
              CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json",
                "postman-token: 115d2b95-729e-7604-005e-09628e9fd8e1"
              ),
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
            //  echo $response;
            }

        $task = json_decode($response);
        print_r($task);
        $title = $task->result->TITLE;
        if(strtolower($title)!="onboarding client"){
            echo 1;
            exit;
        }
        $group_id = $task->result->GROUP_ID;
        $cont_id = $task->result->UF_CRM_TASK[0];
        
        $cont_id= explode("_",$cont_id);
        $cont= $cont_id[1];
        echo $cont;
        //file_put_contents($dir,$cont,FILE_APPEND|LOCK_EX);
    
            $curl = curl_init();
            
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://cc.codeconspirators.com/rest/13/kpylyymjqouoe0v2/crm.contact.get",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => '{"id":"'.$cont.'"}',
              CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json",
                "postman-token: 99e38a00-0b0f-e39e-c8e4-db0991979076"
              ),
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
            //  echo $response;
            }
            
            $cont_detail = json_decode($response);
            
            $name = $cont_detail->result->NAME;
            $email = $cont_detail->result->EMAIL[0]->VALUE; 
            echo $name ."". $email; 
            $password = randomPassword();
            echo $password;
        
          //  file_put_contents($dir,$name,FILE_APPEND|LOCK_EX);
            //file_put_contents($dir,$email,FILE_APPEND|LOCK_EX);
           // file_put_contents($dir,$password,FILE_APPEND|LOCK_EX);
        $user = User::where('email', $email)->first();
        if (!$user) {
            $user = new User();
            $user->name = "sumit";
            $user->email = $email;
            $user->password = Hash::make($password);
            $user->save();
        }

        $project = new Project();
        $project->user_id = $user->id;
        $project->project_id = $group_id;
        $project->save();
        
        
        $maildata = array('email' =>$email,'name'=>$name,'password'=>$password);
        
        
        try{
        Mail::send('email.SendEmail',$maildata, function ($emailMessage) use ($maildata,$email){
            $emailMessage->subject('Welcome To CommandCenter!');
            $emailMessage->to($email);
        });
        }
        catch(\Exception $e){
            echo $e->getMessage();
        }
   
    }
}


function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}
