<?php

namespace app\Auth1;

class  new1
    
 {
    public  function walk(){
        echo "walkingong";
    }
}