<?php
    $archievetoday = date('Y-m-d', strtotime("-30 days"));
?>
@extends('layouts.app')

@if (session('status'))
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    {{ session('status') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @endif

@section('content')
  @include('layouts.headers.cards') 
    
    <div class="container-fluid mt--7" style="background-color:#DCDCDC">
        <div class="row">
            <div class="col-xl-8 mb-5 mb-xl-0">
                <div class="card bg-gradient-default shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h1><b>Messages</b></h1>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body">
                        <div class="chart">
                                <?php
                                $check =0;
                                        for($i=0;$i<count($msg);$i++){
                                            if($msg[$i]){
                                                for($j=0;$j<count($msg[$i]);$j++){
                                                    $msg_date = new \DateTime($msg[$i][$j]['date']);
                                                    $msg_date = $msg_date->format('Y-m-d');
                                                    if($archievetoday < $msg_date){
                                                       // echo "<h3>".$msg_date."</h3><br>";
                                                    }
                                                    else{
                                                        break;
                                                    }
                                                    $check = 1;
                                                    $time1 = new \DateTime($msg[$i][$j]['date']);
                                                    $date = $time1->format('M d, Y');
                                                    echo "<p class='d-inline' style='font-size:16px'>".$msg[$i][$j]['title']."</p><p  class='d-inline' style='color:#999999;font-size:12px'>". "    " .$date."</p><br><br>";
                                                    if($msg[$i][$j]['file']){ 
                                                        $dir = '/files'."/".$msg[$i][$j]['file'];
                                                        ?>
                                                        <div class="iframe-container">
                                                            <iframe class="custom_image_sizing1" id='custom_image_sizing' src="{{asset($dir)}}" frameborder="0" style="overflow: hidden; height: 100%; width: 100%; position: absolute;" height="100%" width="100%"></iframe>
                                                        </div>
                                                        <br>
                                                    <?php
                                                    
                                                    }
                                                }
                                            }
                                        }
                                        if($check == 0){
                                            echo "<h4>You have no active Messages at this time. Check back soon!</h4>";
                                        }
                                    ?>
                                    <a class="archive" href="{{ route('message') }}" style="font-size:16px">Messages Archives</a>
                        </div>
                    </div>
                </div>
                <div class="card bg-gradient-default shadow" style="margin-top:16px">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h1><b>Active Projects</b></h1>
                                
                            </div>
                        </div>
                    </div>                  

                    <div class="card-body">
                        <div class="chart">
                       
                            <?php
                            $check =0;
                                for($i=0;$i<count($projects->result);$i++){
                                    $check =1;
                                    for($k=0;$k<count($project);$k++){
                                if($projects->result[$i]->ID == $project[$k]->project_id){
                               echo "<h3>".$projects->result[$i]->NAME."</h3>";
                                $percent=0;
                                 $var=0;
                                 $var1=0;

                                   
                            for($j=0;$j<count($task_list->result->tasks);$j++){
                                        
                          if($task_list->result->tasks[$j]->groupId == $project[$k]->project_id)
                             {
                                 // echo "<h4>".$task_list->result->tasks[$j]->title."</h4>"; 
                                 $var++;
                                if($task_list->result->tasks[$j]->status==5 )
                                 {
                                  $var1++;
                                 }
                                                    
                                    }    
                                }
                                    if($var == 0){
                                        $percent ="100%";
                                    }
                                    else{
                                     $percent=$var1*100/$var;   
                                    }
                                       
                                    ?>
                                    <div  class="progress" style="height:20px">
                                        <div class="percent" style="width:<?php echo $percent."%"; ?>;background:green">
                                            <p style="width:max-content; margin:3px 15px;"></p>
                                        </div>
                                    </div>
                            
                            <?php
                            $b_status=$task_list->result->tasks[$i]->status;
                             $a=count($task_list->result->tasks);
                          
                             echo "Tasks created this month: (".$var.")"."<br>";
                             echo  "Tasks completed this month: (".$var1.")"."<br><br>";
                                }    
                            }
                            }
                                if($check == 0){
                                            echo "<h4>You have no active Projects at this time. Start something new!</h4><a href='https://b24-5byepi.bitrix24.site/portal-new_project/' target='_blank'>Click Here</a>";
                                        }

                             ?>
                             
                            <a class="archive" href="{{ route('project') }}" style="font-size:16px">Project Archives</a>
                        </div>
                    </div>
                </div>
                <div class="card bg-gradient-default shadow" style="margin-top:16px">
                        <div class="card-header bg-transparent">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h1><b>Support Tickets</b></h1>
                                </div>
                            </div>
                        </div>                                    
                        <div class="card-body">
                            <div class="chart">
                                <?php	
                                $check =0;
                                foreach ($ticketstatus as $resp) { 
                                $check =1;
                                ?>	
                                <div class="container">	
                                    <div class="row">	
                                        <div class="d-inline">	
                                            <h2 class="d-inline"><?php echo $resp['title']; ?> </h2>
                                            <?php $time = new \DateTime($resp['createdDate']);
                                                $date = $time->format('M d, Y');
                                                $time = $time->format('H:i a');
                                            ?>
                                            <p class="d-inline"><?php echo "Submitted ".$date.' at '.$time; ?></p>		 
                                            <?php	
                                            if ($resp['stageId'] == 0 && $resp['status'] != 5) {	
                                                echo "<p class='d-inline' style='color:green'>New</p>";	
                                            } elseif ($resp['stageId'] == 102 && $resp['status'] != 5) {	
                                                echo "<p class='d-inline' style='color:green'>In Progress</p>";	
                                            } elseif ($resp['stageId'] == 104 || $resp['status'] == 5) {
                                                echo "<p class='d-inline' style='color:grey'>Resolved</p>";	
                                            } else {	
                                                echo "<p class='d-inline' style='color:Orange'>Archive</p>";	
                                            }	
                                            ?>
                                        </div>	
                                    </div>	
                                    <div>	
                                      <p> <?php echo $resp['description']; ?> </p>	
                                    </div>	
                                </div>	
                                <?php } 
                                if($check==0){
                                    echo "You have no active Support Tickets. You can request assistance at the button below.";
                                }

                                ?>	
                            </div>
                            <a class="archive" href="{{ route('support') }}" style="font-size:16px">Support Ticket Archives</a>
                            <button type="button" class="btn btn-primary btn ticket" data-toggle="modal" data-target="#exampleModalCenter">REQUEST TICKET</button>	
                        </div>	
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card shadow" >
                            
                     <h2 style="padding:2%;padding-left:1.5rem;"><b>Upcoming Events</b></h2>
                    <div class="card-body" >
                        <div class="chart">
                            <?php
                            $check =0;
                                for($i=0;$i<count($meeting_details);$i++){
                                    for($j=0;$j<count($meeting_details[$i]);$j++){
                                        $check=1;
                                    echo $meeting_details[$i][$j]['name']."<br>";
                                    echo $meeting_details[$i][$j]['date_from']."<br>"; ?>
                                    <a target="_blank" href="<?php echo $meeting_details[$i][$j]['link']; ?>">Link</a><br></br>
                                <?php } }
                                if($check == 0){
                                    echo "<h4>You have no upcoming events. Schedule a call! </h4>";
                                } 
                            ?> 
                        </div>
                    </div>   
                </div>            
                <div class="card shadow" style="margin-top:16px;overflow: auto;">

                            
                        <h2 style="padding:2%;padding-left:1.5rem;"><b>Things We Need</b></h2>

                    <div class="card-body">
                        <div class="chart">
                            <?php
                                $check =0;
                                for($i=0;$i<count($project);$i++){
                                    for($j=0;$j<count($things->result->tasks);$j++){
                                    if($things->result->tasks[$j]->groupId == $project[$i]->project_id){
                                        $check = 1;
                                    echo "<h4 style='margin:0'>".$things->result->tasks[$j]->title."</h4>";  ?>
                                    <p hidden  id="hello2" class="hello2"><?php echo $things->result->tasks[$j]->id ;?></p>
                                     <a class="btn-sm-active-suscribe" data-toggle="modal" data-target="#viewtaskmodal" href="#">View Task</a><br><br>
                                   <?php  }
                                    }
                                }
                                if($check == 0){
                                    echo "<h4>Looks like we have everything we need for the moment! </h4>";
                                }
                            ?>     
                        </div>
                    </div>
                </div>
                <div class="card shadow" style="overflow: auto;margin-top:16px">

                              <h2 style="padding:2%;padding-left:1.5rem;"><b>Open Invoices</b></h2>
                    <div class="card-body">
                        <div class="chart">
                                                        <h4 style="margin:auto">AFUMC-SUP-2010-219</h4>
                            <p>Due: 10/31 $175.00</p>
                            <h4 style="margin:auto">AFUMC-SUP-2009-137</h4>
                            <p>Due: 9/30 $112.50</p>
                            <h4 style="margin:auto">Total: $287.50</h4>

                        </div>
                    </div>   
                </div>            
                <div class="card shadow" style="margin-top:16px;overflow: auto;">          
                    <h2 style="padding:2%;padding-left:1.5rem;"><b>Resource</b></h2>
                    <div class="card-body">
                        <div class="chart">
                            <h4>Resources are coming soon..</h4>
                            
                        </div>
                    </div>   
                </div>            
                <div class="card shadow" style="overflow: auto;margin-top:16px">
                            
                                <h2 style="padding:2%;padding-left:1.5rem;"><b>Links</b></h2>
                           
                    
                    <div class="card-body">
                        <div class="chart">
                            <h4>Links are coming soon..</h4>
                        </div>   
                    </div>            
                
                </div>
            </div>
            	
            <!-- Modal -->	
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form action="{{ route('ticketData') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">New Request</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div  class="modal-body ">

                            <select style="margin-top:10px;" class="form-select form-control" aria-label="Default select example" name="projectname">
                                <option selected>Select your project</option>
                                <?php
                                for ($i = 0; $i < count($projects->result); $i++) {
                                    for ($k = 0; $k < count($project); $k++) {
                                        if ($projects->result[$i]->ID == $project[$k]->project_id) {       ?>
                                            <option value="<?php echo $projects->result[$i]->NAME;  ?> "><?php echo $projects->result[$i]->NAME;  ?></option>
                                <?php  }
                                    }
                                }
                                ?>

                            </select>
                            <div style="margin-top:10px;" class="row">
                                <div class="col"> <input type="text" name="issuetitle" class="form-control" placeholder="Title" /> </div>
                            </div>
                            <div style="margin-top:10px;" class="row">
                                <div class="col "> <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" name="describeissue" rows="3 " placeholder="Describe your Request"></textarea></div>
                            </div>
                            <div style="margin-top:10px;" class="row">
                                <div class="col "> <input class="form-control" type="file" id="img" name="img" accept="image/*"></div>
                               
                            </div>
                            <div style="margin-top:10px;" class="col">
								<div class="form-check">
                                    <input class="form-check-input" type="radio" value="Default" name="flexRadioDefault" id="flexRadioDefault" checked="checked">
                                    <label class="form-check-label" for="flexRadioDefault">
                                   Default
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" value=" Website is down" name="flexRadioDefault" id="flexRadioDefault1">
                                    <label class="form-check-label" for="flexRadioDefault1">
                                    Website is down
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" value="Website is running but there's an issue with the site"  name="flexRadioDefault" id="flexRadioDefault2" >
                                    <label class="form-check-label" for="flexRadioDefault2">
                                    Website is running but there's an issue with the site
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" value="I have a request for a new feature" name="flexRadioDefault" id="flexRadioDefault3" >
                                    <label class="form-check-label" for="flexRadioDefault3">
                                    I have a request for a new feature
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" value="This issue is with a 3rd party service(Pardot,Pharpspring,Google,etc)"  name="flexRadioDefault" id="flexRadioDefault4">
                                    <label class="form-check-label" for="flexRadioDefault4">
                                    This issue is with a 3rd party service(Pardot,Pharpspring,Google,etc)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" value="This relates to an Ongoing Project" name="flexRadioDefault" id="flexRadioDefault5" >
                                    <label class="form-check-label" for="flexRadioDefault5">
                                    This relates to an Ongoing Project
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" value="I'm hav‌gn and issue with my Email Account" name="flexRadioDefault" id="flexRadioDefault6">
                                    <label class="form-check-label" for="flexRadioDefault6">
                                    I'm hav‌gn and issue with my Email Account
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" value="Other" name="flexRadioDefault" id="flexRadioDefault7" >
                                    <label class="form-check-label" for="flexRadioDefault7">
                                    Other
                                    </label>
                                </div>
                               
                            </div>
                            <div style="margin-top:10px;"  class="col">
                            <label  for="issueURL"> <b>URL where the issue Occurs</b></label>
                            <div> <input type="text" name="issueURL" class="form-control" placeholder="You can copy/paste the url from the address bar of your browser window   " /> </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" style="background-color:#c72027;text-align:center;" class="btn btn-primary customcolorformoodle">Send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
            <div class="modal fade" id="viewtaskmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">	
                <div class="modal-dialog modal-dialog-centered" role="document">	
                    <div class="modal-content">	
                        <form action="{{ route('store.thingsweneed') }}" method="POST" enctype="multipart/form-data">	
                            @csrf	
                            <div class="modal-header">	
                                <h5 class="modal-title" id="exampleModalLongTitle">Things we Need</h5>	
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">	
                                    <span aria-hidden="true">&times;</span>	
                                </button>	
                            </div>	
                            <div class="modal-body ">	
                                <div class="row">	
                                    <div class="col "> <input type="hidden" name="taskid" class="form-control" id="service_id" value="" placeholder="Enter name" readonly></div>	
                                </div>	
                                <div class="row">	
                                    <div class="col "> <textarea class="form-control rounded-0" id="exampleFormControlTextarea2" name="taskcomment" rows="3 " placeholder="Add Comment"></textarea></div>	
                                </div>	
                                <div class="row">	
                                    <div class="col "> <input class="form-control" type="file" id="taskimg" name="imgforthingsweneed" accept="image/*" required></div>	
                                </div>	
                            </div>	
                            <div class="modal-footer">	
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>	
                                <button type="submit" class="btn btn-primary">Update</button>	
                            </div>	
                        </form>	
                    </div>	
                </div>	
            </div>
        </div> 
    </div>
    @include('layouts.footers.auth')
@endsection

@push('js')

<script>
    $('.custom_image_sizing1').on('load', function() {
        $('.custom_image_sizing1').contents().find('img').css("width", "100%");
        $('.custom_image_sizing1').contents().find('img').css("height", "100%");
        var images = $('.custom_image_sizing1').contents().find('img');
        console.log(images);
    });
</script>


<script>	
    $(document).ready(function() {	
        $('.btn-sm-active-suscribe').on('click', function() {	
            $('#viewtaskmodal').modal('show');	
            var data = $(this).prev().text();	
          $('#service_id').val(data);	
        });	
    });	
</script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
@endpush