<footer class="py-5" style="background-color:black;height:66px">
    <div class="container">
        @include('layouts.footers.nav')
    </div>
</footer>