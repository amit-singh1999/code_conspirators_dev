<footer class="footer" style="height:66px">
    @include('layouts.footers.nav')
</footer> 