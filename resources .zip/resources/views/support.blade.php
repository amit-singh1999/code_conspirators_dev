@extends('layouts.app')

@section('content')
  @include('layouts.headers.cards') 
  <div class="container-fluid mt--7" style="background-color:#DCDCDC">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card bg-gradient-default shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h2><b>Support</b></h2>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card-body">
                    <div class="chart">
                        <?php
                        $check = 0;
                        foreach ($ticketstatus as $resp) {
                            $time = new \DateTime($resp['createdDate']);
                            $ticket_date = $time->format('Y-m-d');
                            $date = $time->format('M d, Y');
                            $time = $time->format('H:i a');
                       


                            $check = 1;
                        ?>
                            <div class="container">
                                <div class="row">
                                    <div class="d-inline">

                                        <h2 class="d-inline"><?php echo $resp['title']; ?> </h2>
                                        <p class="d-inline"><?php echo "Submitted " . $date . ' at ' . $time; ?></p>
                                        <?php
                                        if ($resp['stageId'] == 0 && $resp['status'] != 5) {
                                            echo "<p class='d-inline' style='color:green'>New</p>";
                                        } elseif ($resp['stageId'] == 102 && $resp['status'] != 5) {
                                            echo "<p class='d-inline' style='color:green'>In Progress</p>";
                                        } elseif ($resp['stageId'] == 104 || $resp['status'] == 5) {
                                            echo "<p class='d-inline' style='color:grey'>Resolved</p>";
                                        } else {
                                            echo "<p class='d-inline' style='color:Orange'>Archive</p>";
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div>
                                    <p> <?php echo $resp['description']; ?> </p>
                                </div>
                            </div>
                        <?php }
                        if ($check == 0) {
                            echo "You have no active Support Tickets. You can request assistance at the button below.";
                        }

                        ?>
                    </div>

                   
                </div>
                </div>
            </div>
        </div>
    </div>    
  @include('layouts.footers.auth')
@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
@endpush