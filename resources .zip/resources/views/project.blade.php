@extends('layouts.app')

@section('content')
  @include('layouts.headers.cards') 
  <div class="container-fluid mt--7" style="background-color:#DCDCDC">
        <div class="row">
            <div class="col-xl-12 mb-5 mb-xl-0">
                <div class="card bg-gradient-default shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h2><b>Project</b></h2>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                    <div class="chart">

                        <?php
                        for ($i = 0; $i < count($projects->result); $i++) {
                            for ($k = 0; $k < count($project); $k++) {
                                if ($projects->result[$i]->ID == $project[$k]->project_id) {
                                    echo "<h3>" . $projects->result[$i]->NAME . "</h3>";
                                    $percent = 0;
                                    $var = 0;
                                    $var1 = 0;


                                    for ($j = 0; $j < count($task_list->result->tasks); $j++) {

                                        if ($task_list->result->tasks[$j]->groupId == $project[$k]->project_id) {
                                            // echo "<h4>".$task_list->result->tasks[$j]->title."</h4>"; 
                                            $var++;
                                            if ($task_list->result->tasks[$j]->status == 5) {
                                                $var1++;
                                            }
                                        }
                                    }
                                    if ($var == 0) {
                                        $percent = "100%";
                                    } else {
                                        $percent = $var1 * 100 / $var;
                                    }

                        ?>
                                    <div class="progress" style="height:20px">
                                        <div class="percent" style="width:<?php echo $percent . "%"; ?>;background:green">
                                            <p style="width:max-content; margin:3px 15px;"></p>
                                        </div>
                                    </div>

                        <?php
                                    $b_status = $task_list->result->tasks[$i]->status;
                                    $a = count($task_list->result->tasks);

                                    echo "Tasks created this month: (" . $var . ")" . "<br>";
                                    echo  "Tasks completed this month: (" . $var1 . ")" . "<br><br>";
                                }
                            }
                        }
                        ?>

                    </div>
                
                </div>
            </div>
        </div>
    </div>    
  @include('layouts.footers.auth')
@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
@endpush