<table cellpadding="0" cellspacing="0" style="vertical-align: -webkit-baseline-middle; font-size: medium; font-family: Arial;">
<tbody>
<tr>
    <td>
        <p>Hello &nbsp;&nbsp; </p>
        <p>You are receiving this email because we received a password reset request for your account.&nbsp;</p>
            <a style="background-color:#c72027;box-sizing:border-box; border-radius:4px; color:#fff; display:inline-block; overflow:hidden; text-decoration:none; border-bottom:8px solid #c72027; border-left:18px solid #c72027; border-right:18px solid #c72027; border-top:8px solid #c72027" data-linkindex="1" href="https://portal.codeconspirators.com/password/reset/<?php echo $token ?>?email=<?php echo $email ?>" >Reset Password </a>
        <p>This password reset link will expire in 60 minutes.</p>
        <p>If you did not request a password reset, no further action is required.</p>
</td>
</tr>
</tbody>
</table>
<table cellpadding="0" cellspacing="0" style="vertical-align: -webkit-baseline-middle; font-size: medium; font-family: Arial;"><tbody>
    <tr>
        <td>
        </td>
    </tr>
    <tr>
      <td valign="top"><div style="width: 10px; height:10px;"></div></td>
      <td valign="top"><table cellpadding="0" cellspacing="0" class="sc-jDwBTQ dWtMUn" style="vertical-align: -webkit-baseline-top; font-size: medium; font-family: Arial;"><tbody>
            <tr>
              <td style="vertical-align: middle;"><div style="width: 30px; height:10px;"></div></td>
            </tr>
            <tr>
              <td valign="top" style="vertical-align: top; padding-top:5px; padding-right:10px;"><h3 color="#444444" class="sc-jhAzac hmXDXQ" style="margin: 0px; font-size: 18px; color: rgb(68, 68, 68);"><span>
                Codee</span></h3>
              <p color="#444444" font-size="medium" class="sc-fMiknA bxZCMx" style="margin: 0px; font-weight: 500; color: rgb(68, 68, 68); font-size: 14px; line-height: 22px;"><span></span></p></td>
            </tr>
            <tr>
              <td valign="top" style="vertical-align: top; padding-top:5px; padding-right:10px;"><div style="width: 1px; height:5px;"></div></td>
            </tr>
            <tr>
              <td valign="top" align="left" style="vertical-align: top; text-align: left; padding-top:5px; padding-right:10px;"><a href="https://codeconspirators.com" target="_blank"><img src="http://codeconspirators.com/wp-content/uploads/2019/10/logo-CC-horz-250.jpg" /></a></td>
            </tr>
            </tbody>
</table></td></tr></tbody></table>
<br />
<br />
