<div class="row align-items-center justify-content-xl-between" style="margin-right:0">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; {{ now()->year }} by <a  href="https://www.codeconspirators.com/" class="font-weight-bold ml-1 text-white" target="_blank">CodeConspirators</a>, All Rights Reserved 
        </div>
    </div>
    <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end" style="margin-right:2%">
            <li class="nav-item">
                <a href="https://www.codeconspirators.com/p/terms/" class="nav-link" target="_blank">Terms</a>
            </li>
            <li class="nav-item">
                <a href="https://www.codeconspirators.com/p/privacy/" class="nav-link" target="_blank">Privacy</a>
            </li>
            
        </ul>
    </div> 
</div>