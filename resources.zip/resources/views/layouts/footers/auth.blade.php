<footer class="footer" style="background-color:black;width:100%;margin-top:auto;bottom:0;">
    @include('layouts.footers.nav')
</footer> 