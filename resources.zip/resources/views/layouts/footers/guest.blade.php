<footer class="py-3" style="background-color:black;height:66px;width:100%;margin-top:auto;bottom:0;">
    <div class="container">
        @include('layouts.footers.nav')
    </div>
</footer>