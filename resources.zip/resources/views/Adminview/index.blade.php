@extends('adminlayout.final')
@section('title', 'Users')
        <!-- Page Content  -->
        @section('content')
        <!-- Page Content  -->
        <div id="content" class="p-4 p-md-5 pt-5">
            <div>
                <table class="table " id="datatable">
                      <thead><tr ><h3 style="margin:8px">Users</h3></tr></thead>
                    <thead>
                        <tr>
                            <!--<th scope="col">User Id</th>-->
                            <th scope="col">Name</th>
                            <th scope="col">Role</th>
                            <th scope="col">Login</th>
                            <th scope="col">Action</th>
                           
                        </tr>
                    </thead>
                    <tbody class="table_body_color">           
                            @foreach ($data as $userdata_info)
                            <tr>
                            <td>{{$userdata_info['name']}}    </th>
                            <td>{{$userdata_info['role']}}  </th>
                            <td>
                               
                                @if($userdata_info['login_details'][0]  != 0)
                                @php
                                $datenew = date_create($userdata_info['login_details'][1]);
                                 
                          
                                echo date_format($datenew,"Y/m/d H:i:s");
                                @endphp
                                 {{"[".$userdata_info['login_details'][0]."]"}}
                                  
                                @else
                                 
                                {{"Not logged in yet"}}
                                @endif
                               
                              
                                
                                
                            </th>
                            <td ><a href="{{url('/dashboard/user/edit/'.$userdata_info['id'])}}" class="link_color" ><i class="fas fa-edit"></i></a> <a onclick="return confirm('Are you sure?')" href="{{url('/dashboard/user/delete/'.$userdata_info['id'])}}" class="link_color" ><i class="far fa-trash-alt"></i></a> </th>
                            
                            </tr>
                            @endforeach
                    </tbody>
                </table>
            </div>

        </div>
@endsection