@extends('adminlayout.final')
        <!-- Page Content  -->
        @section('content')
        <div id="content" class="p-4 p-md-5 pt-5">
            <div class="table_body_color">
                <form  action="{{ route('userdetailUpdate',$userdata->id)}}" method="POST">
                    @csrf   
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Email</label>
                            <input type="email" class="form-control" name="email" id="inputEmail4"  value="{{$userdata->email}}" readonly >
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Name</label>
                            <input type="text" class="form-control" id="inputPassword4" name="Name" placeholder="Name" value="{{$userdata->name}}">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Phone</label>
                            <input type="number" class="form-control" id="inputEmail4" name="Phone" placeholder="Number" value="{{$userdata->phone}}">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Created at</label>
                            <input type="text" class="form-control" id="inputPassword4" placeholder="Created Time" value="{{$userdata->created_at}}">
                        </div>
                    </div>
                    <div class="form-row">
                      
                        <div class="form-group col-md-4">
                            <label for="inputState">Role</label>
                            <select id="inputState" name="role" class="form-control">
                                <option selected>{{$userdata->role}}</option>
                                <option value="Admin">Admin</option>
                                <option value="Strategist">Strategist</option>
                                <option value="Operative">Operative</option>
                            </select>
                        </div>
                       
                    </div>
                    <button type="submit" class="btn btn-custom">Update here</button>
                </form>



            </div>

        </div>
        @endsection


  