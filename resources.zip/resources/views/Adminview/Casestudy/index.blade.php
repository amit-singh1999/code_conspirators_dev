@section('title', 'Case Studies')
<div class="container-fluid mt--7" >
    <div class="row">
        
               @if (Session::has('message'))
               <div class="alert alert-info">{{ Session::get('message') }}</div>
               @endif
               
               
            <div class="col-xl-12 mb-5 mb-xl-0">
            <div class="card bg-gradient-default shadow" style="margin-bottom:6%">
                <div class="card-header bg-transparent">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2><b>Case Studies</b></h2>
                            @if(Illuminate\Support\Facades\Auth::user()->role=="Admin")
                               <div class="container" style="margin-top:-10px">
                                <div class="row" style="float:right;margin-top: -27px"><h3><b>Add Case Study</b></h3>
                                  <div style="float:right;margin: 10px">  <a href="{{route('casestudy.create')}}">
                                     <i class="fa fa-plus-square-o fa-2x" style="color:red;" aria-hidden="true"></i>
                                    </a></div>
                                </div>
                                </div>
                            @endif
                        </div>
                    </div>
               
                </div>
                <div class="card-body">
                    <div class="chart">
                        <table class="table table-bordered table-responsive-lg">
                            <tr>
                                <th>Client name</th>
                                <th>Case Study</th>
                                <th>Description</th>
                                <th>Logo</th>
                                
                                
                                 <th>Action</th>
                                
                            
                            </tr>
                         
                           
                            @foreach($Casestudy as $data)
                                <tr>
                                 <td>{{ $data->Clientname}}</td>
                                 <td>{{ $data->caseStudyName}}</td>
                                 <td>{!! $data->description !!}</td>
                                 <td>
                                     @if($data->Client_company_logo)
                                     <img width="100" height="100" src="{{ asset('ClientLogo/'. $data->Client_company_logo) }}" alt="" border="0"/> 
                                     @endif
                                 </td>
                                   <th >
                                        <a href="{{url('/dashboard/CaseStudy/edit/'.$data->id)}}" class="link_color" ><i class="fas fa-edit"></i></a>
                                        <a onclick="return confirm('Are you sure?')" href="{{url('/dashboard/CaseStudy/delete/'.$data->id)}}" class="link_color" ><i class="far fa-trash-alt"></i></a> </th>
                                  </tr>
                                  
                            @endforeach
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>