@extends('adminlayout.final')
<!-- Page Content  -->
@section('content')
<!-- Page Content  -->
<div id="content" class="p-4 p-md-5 pt-5">
    @include('Adminview.Casestudy.index') 
  
</div>
@endsection
