<footer class="footer admin-footer-style">
    @include('adminlayout.footerlayout')
</footer> 