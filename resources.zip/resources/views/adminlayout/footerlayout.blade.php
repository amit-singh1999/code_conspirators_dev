<div class="row align-items-center justify-content-xl-between" style="margin-right:0">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted footertextstyle footercolor">
            &copy; {{ now()->year }} by <a href="https://www.codeconspirators.com/" class="font-weight-bold ml-1 link_color" target="_blank">CodeConspirators</a>, All Rights Reserved 
        </div>
    </div>
    <div class="col-xl-6 ">
          <p class="footerportalversion  footercolor">    Admin Portal, Version 1.0</p>
     
    </div> 
</div>
