<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"
          integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">
    <!-- google-fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet"/>
    <!-- Font awosome icon  -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
          integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

    <!--<link rel="stylesheet" href="https://codeconspirators.com/_resources/proposal/style.css" />-->
    <link rel="stylesheet" href="https://files.codeconspirators.com/_resources/proposal/style.css"/>
    <link rel="stylesheet" href="{{ asset('adminstyle') }}/css/propsal.css"/>

    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" />-->
    <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>-->
    <script src="https://code.jquery.com/jquery-2.2.4.js"
            integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI=" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <style>
        .mksmall {
            font-size: 1.3rem !important;
        }

        /* Accordion */
        .accordion,
        .accordion * {
            box-sizing: border-box;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
        }

        .conspirator-item:hover {
            background: #E5CFA2;
        }

        .accordion {
            overflow: hidden;
        }

        /* Section Title */
        .section-title {
            background: none;
            display: inline-block;
            width: 100%;
            padding: 0px;

        }

        section#main {
            height: 87vh !important;
        }

        .section-title.active,
        .section-title:hover {

        }

        .section:last-child .section-title {
            border-bottom: none;
        }

        .section-title:after {
            /* Unicode character for "plus" sign (+) */
            content: '\02795';
            font-size: 13px;
            color: #FFF;
            float: right;
            margin-left: 5px;
        }

        .section-title.active:after {
            /* Unicode character for "minus" sign (-) */
            content: "\2796";
        }

        /* Section Content */
        .section-content {
            display: none;
            padding: 20px;
        }
    </style>
    <script>
        var j = jQuery.noConflict();
        j(document).ready(function () {
            j('.section-content').dblclick(function (e) {

                close_section();
            })

            j(document).on('click', "#edit-item", function () {


                j(this).addClass(
                    'edit-item-trigger-clicked'
                ); //useful for identifying which trigger was clicked and consequently grab data from the correct row and not the wrong one.

                var options = {
                    'backdrop': 'static'
                };
                jQuery('#edit-modal').modal()
            })

            j('.section-title').click(function (e) {
                // alert(1);
                // Get current link value
                var currentLink = j(this).attr('href');
                if (j(e.target).is('.active')) {
                    close_section();
                } else {
                    close_section();
                    // Add active class to section title
                    j(this).addClass('active');
                    // Display the hidden content
                    j('.accordion ' + currentLink).slideDown(350).addClass('open');
                }
                e.preventDefault();
            });

            function close_section() {
                j('.accordion .section-title').removeClass('active');
                j('.accordion .section-content').removeClass('open').slideUp(350);
            }


        })


    </script>

    <title>Action Plan for {{$UsernameofQuote->result->NAME}}</title>
</head>

<body>
<main>

<div class="main-body-left iborder">


</div>
<div class="main-body-right">


<div class="main-body-content-box">

<div class="scroll-function">

<!-- Home section start  -->
<section id="home">
    <h1>
        Welcome,

        <!--{{$company_Title}}-->

        {{$UsernameofQuote->result->NAME}}.
    </h1>

    <p>
        You're on a mission. We get that, and we're here to support. <br>Here's our plan of attack.
    </p>

    <h1>
        <a name="MissionBriefing">
            Mission Briefing
        </a>
    </h1>

    <p>
        Your business deserves online marketing that is so much more than pictures, colors, and fonts on a computer
        screen. It begins with a marketing strategy that targets your perfect client and ends where your business
        objectives and your clients’ needs intersect.
        That intersection is what we like to call our "secret code”. If each marketing effort is not strategically
        planned and executed, it can actually do more harm than good. Producing a consistent, effective message
        across all of your internet properties will encourage increased market share and long-term
        profitability.<br><br> Our team of marketing professionals has years of experience
        helping businesses get the most value for their marketing dollars. See how our experience can benefit you, and
        allow you to focus on what you do best! While each business is unique and requires a unique approach,
        listed throughout this proposal are the services we know will work best for you. </p>
 
    <h1>
        <a name="Overview">
            Overview
        </a>
    </h1>

    <p>
        Our goal at Code Conspirators is to predictably and efficiently generate new leads for our marketing clients.
        Based on the volume and scope of work projected in the future, the most cost effective approach is a retainer
        agreement. Benefits of a retainer
        agreement include:<br>
    <ul>
        <li>
            Reliable Budget - Establishing a finite number of marketing hours each month yields consistent billing and
            reliable budgeting.
        </li>
        <li>
            Transparent Billing Structure - With a retainer in place, we provide you with a “proof then payment” billing
            structure. We will not exceed the agreed upon marketing hours each month without explicit approval in
            writing to do so.
        </li>
        <li>
            Discounted Hourly Rates - Our rates under a retainer agreement are discounted, depending on the retainer
            option selected.
        </li>
        <li>
            Retainer-Exclusive Benefits - In addition to our rate discounts, we offer other retainer- exclusive benefits
            not otherwise available, as noted in the table below.
        </li>
    </ul>
    </p>
    <h3>
        <a name="SEO">
            SEO: Search Engine Optimization
        </a>
    </h3>

    <p>
        Creating a solid digital marketing strategy for your business isn’t always easy. SEO is complex and having the
        right plan takes time, skill, and effort. And, as more companies discover the value of an optimized website, the
        market has become increasingly
        saturated, making it difficult to navigate without a solid partner to help you stand out. That’s where we come
        in. Simply put, we are here to help you grow your visibility and increase leads.</p><br>

    <h4 class="quote">The right digital marketing team can get you seen through SEO. The wrong one can leave you in a
        deep, dark cave.</h4><br>

    <p>SEO is one big game of ‘who do you know’ for platforms like Google. The more people who connect with your site
        using optimized keywords, the more these search engines are likely to trust you when referring others scouring
        the web using those same words. But stuffing a bunch of keywords onto a page and hoping for the best is not the
        way to get the job done.
    </p>

    <h3>
        <a name="SEM">
            SEM: Search Engine Marketing
        </a>
    </h3>

    <p>
        If you’re just getting started with paid advertising or SEM, we can help and we can get you up and running with
        a new campaign in as little as thirty days. Of course, this isn’t something you just want to dive into without a
        bit of research into your
        target demographics, keywords, an established budget, and more. Our Code Conspirators team can not only take
        care of the grunt work for you, we’ll leverage our expertise to ensure your ads cut through the noise
        of organic and other paid search results.
    </p>

    <div class="highlighted">
        <h4>
            What about Ad Spend?
        </h4>

        <p>
            Great question! Ad spend is fully customizable to your needs and budget, which is why it's in addition to
            your monthly retainer cost. You'll pay Google directly - no middle man... or woman.
        </p>
    </div>

</section>


<!-- Home section end  -->
<form action="{{route('createinvoicefortemplate')}}" method="POST">
@csrf


<!-- Conspirators section start -->
<section id="conspirator" class="pt-5">
    <h1>
        <a name="Solutions">
            Solutions
        </a>
    </h1>

    <p>
        We've crafted a plan with your success at the center, because you've chosen to work with us
        for our expertise. But remember: you've also chosen us because our plans are flexible. Want
        something more? Want something different? Just let us know
    </p><br>

    
    <?php
    $keyscontainer = [];


    // echo "<pre>";

    // echo "</pre>";


    $keyshere = array_keys($FinalProductArraycopy);
    $queryselectrorvalue = 0;
    for ($i = 0; $i < count($keyshere); $i++) {
        $keyofcopyarray = $keyshere[$i];


        echo "<h2>" . $keyofcopyarray . "</h2>";


        $accessdata = $FinalProductArraycopy[$keyofcopyarray];


        for ($j = 0; $j < count($accessdata); $j++) {
            $queryselectrorvalue = $queryselectrorvalue + 1;
            //  echo $accessdata[$j]['productid'];
            $productid = $accessdata[$j]['productid'];
            //  echo "<br>";
            //  echo $accessdata[$j]['productname'];
            $productname = $accessdata[$j]['productname'];
            //  echo "<br>";
            //  echo $accessdata[$j]['productprice'];
            $productprice = $accessdata[$j]['productprice'];
            //  echo "<br>";
            //  echo $accessdata[$j]['productdescription'];
            $productdescription = $accessdata[$j]['productdescription'];
            //  echo "<br>";
            //  echo $accessdata[$j]['Monthly'];
            $Monthly = $accessdata[$j]['Monthly'];
            //  echo "<br>";
            //  echo $accessdata[$j]['prechecked'];
            $prechecked = $accessdata[$j]['prechecked'];
            //  echo "<br>";
            //  echo $accessdata[$j]['ProductSection'];
            $ProductSection = $accessdata[$j]['ProductSection'];
            //  echo "<br>";
            //  echo "subal";
            //  echo "<br>";


            if ($ProductSection == 187) {
                ?>
                <!--// array_push($containera,$newarrayhere);-->
                <!--defautl-->
                <div class="conspirator-item-wrapper mt-5"
                     style="font-size:180%;">
                    <div class="conspirator-item">
                        <div class="conspirator-item-left">
                            <h4 class="conspirator-item-title text-capitalize"> <?php echo $productname; ?></h4>

                            <p class="conspirator-item-text">

                                <?php echo $productdescription; ?>
                            </p>
                        </div>
                        <div class="conspirator-item-right">
                            <input type="hidden" name="preselected[]" required value="<?php echo $productid ?>"/>
                            <!--//coment for undestanding  code-->
                            <strong class="conspirator-rate CalculatePricepreselected">
                                <?php echo '$' . $productprice ?> <?php echo $Monthly == 1 ? "/Month" : ""; ?> </strong>
                            <!-- <button class="conspirator-select">&radic; select</button> -->

                        </div>
                    </div>
                </div>


            <?php
            }
            if ($ProductSection == 189) {
                ?>
                <!--//   array_push($containerb,$newarrayhere);-->
                <!--checkbox-->
                <div class="conspirator-item-wrapper mt-5" onclick="SelectRadioAfterclick({{$queryselectrorvalue}},'c')"
                     style="<?php echo $prechecked == 1 ?"font-size:180%":"" ?>">

                    <div class="conspirator-item">
                        <div class="conspirator-item-left">
                            <h4 class="conspirator-item-title text-capitalize"> <?php echo $productname ?></h4>

                            <p class="conspirator-item-text">
                                <?php echo $productdescription ?>
                                <!--It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).-->
                            </p>
                        </div>
                        <div class="conspirator-item-right">

                            <strong
                                class="conspirator-rate"><?php echo '$' . $productprice ?> <?php echo $Monthly == 1 ? "/Month" : ""; ?>
                                <input type="checkbox" onchange="mainFunctionTocalculateprice('c')"
                                       id="{{$queryselectrorvalue}}" name="Priceconspirator[]"
                                       value="<?php echo $productid ?>" <?php echo $prechecked == 1 ? "checked" : ""; ?> ></strong>
                            <!-- <button class="conspirator-select">&radic; select</button> -->
                        </div>
                    </div>
                </div>



            <?php
            }
            if ($ProductSection == 191) {
                ?>
                <!--container c-->

                <div class="conspirator-item-wrapper mt-5" onclick="SelectRadioAfterclick({{$queryselectrorvalue}},'c')"
                     style="<?php echo $prechecked == 1 ? "font-size:180%;" : ""; ?>">
                    <div class="conspirator-item">
                        <div class="conspirator-item-left">
                            <h4 class="conspirator-item-title text-capitalize"> <?php echo $productname ?></h4>

                            <p class="conspirator-item-text">
                                <!--t is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).-->
                                <?php echo trim($productdescription); ?>
                            </p>
                        </div>
                        <div class="conspirator-item-right">
                            <strong
                                class="conspirator-rate  CalculatePriceCheckbox"><?php echo '$' . $productprice; ?><?php echo $Monthly == 1 ? "/Month" : ""; ?>
                                <input type="checkbox" onchange="mainFunctionTocalculateprice('c')"
                                       id="{{$queryselectrorvalue}}" name="Priceconspirator[]"
                                       value="<?php echo $productid ?>" <?php echo $prechecked == 1 ? "checked" : ""; ?>  ></strong>
                            <!-- <button class="conspirator-select">&radic; select</button> -->
                        </div>
                    </div>
                </div>

            <?php
            }
            if ($ProductSection == 193) {
                ?>
                <!--//   array_push($containerd,$newarrayhere);-->
                <div class="conspirator-item-wrapper mt-5"
                     onclick="SelectRadioAfterclick({{$queryselectrorvalue}},'r')">
                    <div class="conspirator-item">
                        <div class="conspirator-item-left">
                            <h4 class="conspirator-item-title text-capitalize"><?php echo $productname ?></h4>

                            <p class="conspirator-item-text"><br>
                                <?php echo $productdescription; ?>
                            </p>

                        </div>
                        <div class="conspirator-item-right">
                            <strong
                                class="conspirator-rate "><?php echo '$' . $productprice ?> <?php echo $Monthly == 1 ? "/Month" : ""; ?>  </strong>

                            <div class="CalculatePriceRadio">
                                <h2 style="display: inline;margin-right: 32px;">Select</h2>
                                <input type="radio" onchange="mainFunctionTocalculateprice('r')"
                                       id="{{$queryselectrorvalue}}" name="selectone" value="<?php echo $productid ?>">
                            </div>


                        </div>
                    </div>
                </div>




            <?php
            }


        }

    }


    ?>




    <div class="row">
        <div clas="col ml-5" style="display: flex;justify-content: end;">
            <h1>
                <div id="OnetimepriceAppend"></div>
            </h1>
        </div>

        <div clas="col ml-5" style="margin-top: -61px;display: flex;justify-content: end;">
            <h1>
                <div id="MonthlypriceAppend"></div>
            </h1>
        </div>

    </div>


</section>

<!-- Conspirators section end  -->

<!-- schedule section start  -->
<section id="schedule" class="pt-5">
    <h3>
        <a name="Schedule">
            Schedule
        </a>
    </h3>

    <div class="schedule-body ">
        <table class="schedule-table">
            <thead>
            <tr>
                <th class="schedule-table--head">activities</th>
                <th class="schedule-table--head">Timing</th>
                <th class="schedule-table--head">Amount</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td class="schedule-table-data">KickOFF</td>
                <td class="schedule-table-data">Before Launch</td>
                <td class="schedule-table-data">included!</td>
            </tr>
            <tr>
                <td class="schedule-table-data">Set-Up/Optimization</td>
                <td class="schedule-table-data">Month"Zero"</td>
                <td class="schedule-table-data">Deposit Installment</td>
            </tr>
            <tr>
                <td class="schedule-table-data">Marketing Servies</td>
                <td class="schedule-table-data">Months 1-6 or 12</td>
                <td class="schedule-table-data">Monthly Installment</td>
            </tr>
            </tbody>
        </table>
    </div>
</section>
<!-- schedule section end  -->
<!-- Case Studies  -->
<h1>
    <a name="CaseStudies">
        Case Studies
    </a>
</h1>

<p>
    Intro paragraph here.
</p><br>
<!-- Case Studies end -->

<!-- service agremeent  -->
<h1>
    <a name="ServiceAgreement">
        Service Agreement
    </a>
</h1>

<p class="headstyle">
    <strong><span class="spantext">PROVISIONS OF AGREEMENT</span></strong>
</p>

<p class="headstyle">
    <span class="spantext">Upon completion of the project and payment in full
        of all invoices, Client shall retain ownership rights to work performed within the confines of this agreement,
        including but not limited to the Website or Web Application in its delivered state.</span>
</p>

<p class="headstyle">
    <span class="spantext">Fees paid to Code Conspirators by the client are
        for services provided, including but not limited to consultation, strategy, design, and development. Additional
        fees may be incurred for any licenses, royalties, or other costs that are not associated with services provided
        by Code Conspirators. [Additional anticipated fees, if any, will be listed in the Fee Schedule and agreed to
        before they are incurred]. Any amount over the agreed proposed amount needs to be written client approval before
        proceeding with work and incurring fees.</span>
</p>

<p class="headstyle">
    <span class="spantext">Code Conspirators offers support at no charge for
        30 days following deployment. No maintenance contract is required thereafter, but the Client will have the
        rights to manage the Website, and to secure assistance from Code Conspirators for additional support at Code
        Conspirators&rsquo;s then prevailing rates, or by engaging in a Retainer Agreement with Code Conspirators, or to
        engage support from a third-party provider at the Client&rsquo;s discretion.</span>
</p>

<p class="headstyle">
    <span class="spantext">Code Conspirators retains the right to reference
        the project in digital or printed collateral, including but not limited to a portfolio, case study, or client
        list.</span>
</p>

<p class="headstyle">
    <span class="spantext">Code Conspirators retains the right of ownership
        of the intellectual property to any computer software and other intellectual property underlying, incorporated
        into or embedded in the Website or used in custom modules and technologies and provided by Code Conspirators or
        its suppliers, as well as any</span>
</p>

<p class="headstyle">
    <span class="spantext">(i) search mechanisms, software
        &quot;engines&quot;, scripting routines, and other higher-level or proprietary languages (together with any
        graphic or digital video extensions thereof),</span>
</p>

<p class="headstyle">
    <span class="spantext">(ii) pre-existing or non-specific content, text,
        illustrations, and other graphical elements, and</span>
</p>

<p class="headstyle">
    <span class="spantext">(iii) general know-how, expertise, concepts,
        authoring tools, designs, programs, devices, methods, techniques (including video and audio digitalization
        techniques) and processes utilized by Code Conspirators in the course of its performance hereunder, and the
        right to utilize those technologies in future endeavors for other clients, provided that Code Conspirators does
        not utilize Client confidential information in such endeavors.</span>
</p>

<p class="headstyle">
    <span class="spantext">Client retains the right of ownership of the
        Website itself and the right to use all computer software (including all computer programming code and
        documentation) incorporated into or embedded in the Website or used in custom modules and technologies and
        provided by Code Conspirators or its suppliers, as well as any</span>
</p>

<p class="headstyle">
    <span class="spantext">(i) search mechanisms, software
        &quot;engines&quot;, scripting routines, and other higher-level or proprietary languages (together with any
        graphic or digital video extensions thereof),</span>
</p>

<p class="headstyle">
    <span class="spantext">(ii) pre-existing or non-specific content, text,
        illustrations, and other graphical elements, and</span>
</p>

<p class="headstyle">
    <span class="spantext">(iii) the results of general know-how, expertise,
        concepts, authoring tools, designs, programs, devices, methods, techniques (including video and audio
        digitalization techniques), and processes utilized by Code Conspirators in the development of the
        Website.</span>
</p>

<p class="headstyle">
    <span class="spantext">Upon deployment of the marketing campaign, Client
        will not be in any way tied to, committed to, or otherwise dependent on Code Conspirators for successful
        operation, maintenance, or accessibility of the Website or any component or asset thereof.</span>
</p>

<p class="headstyle">
    <strong><span class="spantext">SCOPE OF AGREEMENT</span></strong>
</p>

<p class="headstyle">
    <span class="spantext">Funds deposited with Code Conspirators for work
        performed are non-refundable, except as expressly set forth in this agreement.</span>
</p>

<p class="headstyle">
    <strong><span class="spantext">Client Participation</span></strong><span class="spantext">&nbsp;- As with any
        project, the more we know about
        the driving business factors, requirements, and expectations, the better we can prepare our staff to meet all
        project requirements. In order to fully perform the services outlined in this agreement, a certain level of
        client participation is required in each project we work on.</span>
</p>

<p class="headstyle">
    <span class="spantext">Some projects require less participation than
        others, while some require almost daily or weekly meetings and updates. The parties will discuss such level of
        participation upon commencement and during the course of the services, and Client will provide such information
        and participation reasonably required by Your Design Online in order to perform its obligations hereunder, in
        addition to the information requested to be provided by Client as set forth in this agreement.</span>
</p>

<p class="headstyle">
    <strong><span class="spantext">Electronic
            Communication</span></strong><span class="spantext">&nbsp;- By
        approving this proposal you give your consent to Your Design Online to communicate to you via email and/or print
        communications. Future communications may include automated voice or other communication mediums as they become
        available.<br>&nbsp;Agreement Term - In the event of any ongoing services provided by Code Conspirators, this
        agreement will take effect on the date accepted and signed by the Client below (&ldquo;Effective Date&rdquo;)
        and will remain in effect for a period of twelve (12) months (the &ldquo;Initial Term&rdquo;). Upon expiration
        of the Initial Term, any continuation shall be via execution of a new agreement.</span>
</p>

<p class="headstyle">
    <span class="spantext">There are only recurring services within the scope
        of this agreement if they are selected on the Next Steps page.</span>
</p>

<p class="headstyle">
    <span class="spantext">Customers may cancel any applicable monthly
        recurring services at any time with thirty (30) days written notification and receive a refund for pre-paid fees
        for services in months not yet performed.</span>
</p>

<p class="headstyle">
    <span class="spantext">Upon termination of this agreement for any reason,
        all amounts outstanding shall become immediately due and payable, including, but not limited to, any fees for
        website design that have not been paid in full as of the termination effective date.</span>
</p>

<p class="headstyle">
    <strong><span class="spantext">Payment</span></strong><span class="spantext">&nbsp;- Payment may be made by check,
        credit card,
        or ACH. Please see the details on any invoice from Code Conspirators.</span>
</p>

<p class="headstyle">
    <span class="spantext">&nbsp;</span>
</p>

<p class="headstyle">
    <span class="spantext">The client agrees to pay any such outstanding
        amounts due within the agreed-upon terms upon receipt of an invoice from Code Conspirators. In the event, Client
        fails to pay any invoice in full when due, Client shall, in addition to the invoice amount, pay Code
        Conspirators interest on such unpaid balance at the lesser of one percent (1%) simple interest per month or the
        highest rate of interest permitted by law with respect to such balance.</span>
</p>

<p class="headstyle">
    <span class="spantext">The client shall also reimburse Code Conspirators
        for any collection costs incurred by Code Conspirators, including attorneys&rsquo; fees.</span>
</p>

<p class="headstyle">
    <strong><span class="spantext">Arbitration</span></strong><span class="spantext">&nbsp;- The parties have agreed
        that the validity,
        interpretation, implementation, and resolution of disputes of this agreement shall be governed by the laws of
        the State of Georgia, without reference to its conflicts of law principles.</span>
</p>

<p class="headstyle">
    <span class="spantext">In the event a dispute arises pursuant to this
        agreement, including any dispute regarding its breach, termination, validity, or interpretation, the parties
        agree to attempt in good faith to resolve such dispute by consultation of the parties.</span>
</p>

<p class="headstyle">
    <span class="spantext">If the parties are unable to resolve such dispute
        within 20 days of the first notice of the dispute, after reasonable attempts to do so, the parties agree to
        submit the dispute to binding arbitration pursuant to the then-existing Commercial Arbitration Rules of the
        American Arbitration Association. Such arbitration shall take place in Milton, Georgia before a single
        arbitrator.</span>
</p>

<p class="headstyle">
    <span class="spantext">The parties shall endeavor to select a mutually
        acceptable arbitrator knowledgeable about issues relating to the subject matter of this agreement.</span>
</p>

<p class="headstyle">
    <span class="spantext">The arbitrator shall base his decision on the
        provisions of this agreement and relevant governing law.</span>
</p>

<p class="headstyle">
    <span class="spantext">The arbitrator shall not award punitive or
        exemplary damages. Any judgment or award rendered by such arbitrator shall be final and binding on all parties
        to the proceeding, may be entered into with the highest court of competent jurisdiction for enforcement as a
        final judgment adjudication. The prevailing party will be awarded reasonable attorney fees, together with any
        costs and expenses, to resolve the dispute and to enforce the final arbitration award, except as otherwise
        determined by the arbitrator.</span>
</p>

<p class="headstyle">
    <span class="spantext">All arbitral proceedings and documents exchanged
        during arbitration shall be held confidential by both parties and the arbitrator.</span>
</p>

<p class="headstyle">
    <span class="spantext">Notwithstanding anything in this agreement to the
        contrary, either party may seek interim and/or permanent injunctive or declaratory relief as appropriate, from
        any court of competent jurisdiction, and any injunctive or declaratory relief so obtained shall not be subject
        to arbitral review.</span>
</p>

<p class="headstyle">
    <strong><span class="spantext">LIMITATIONS OF OFFER</span></strong>
</p>

<p class="headstyle">
    <span class="spantext">This proposal is valid for 30 days from the date
        of submission.</span>
</p>
</div>
<!-- section-content end -->
</div>
<!-- section end -->

</div>
<!-- accordion end -->
<!-- Attachment Accordian end -->
<!-- service agremeent end -->


<!-- next steps  -->
<h1>
    <a name="NextSteps">
        Next Steps
    </a>
</h1>

<p>
    Ready to get started? <span style="color:#222222;"><strong>Awesome, so are we!</strong></span><br/><br/>
    Please <span style="color:#222222;"><strong>1) make your selections (above)</strong></span>,
    and then <span style="color:#222222;"><strong>2) sign (below)</strong></span>.<br/>
    You'll receive an initial invoice shortly, <br/>and a Strategist will reach out to get this moving.
</p><br>

<div class="container">
    <br>
    <?php echo isset($msg) ? $msg : ''; ?>
    <h4>Sign below:</h4>
    <hr>
    <div id="canvasDiv" style="width:100%;background: white;opacity: 0.8;"></div>
    <br>
    <!--<button type="button" class="btn btn-success" id="btn-save">Save</button>-->
    <!--<form id="signatureform" action="" style="display:none" method="post">-->
    <input type="hidden" id="signature" name="signature">
    <input type="hidden" name="signaturesubmit" value="1">
    <!--</form>-->
</div>

<input type="hidden" id="custId" name="dealIdhere" value="{{$datanew->result->ID}}">
</form>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha256-pasqAKBDmFT4eHoN2ndd6lN370kFiGUFyTiUHWhU7k8=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.5.0-beta4/html2canvas.min.js"></script>
<!--//product price calculation-->
<script>


    // all checkbox calculations   

    function mainFunctionTocalculateprice(key) {
        //  if(key =='c'){
        //  console.log("this is c");
        checkboxresult = CheckboxFunction();
        //  console.log(checkboxresult);
        //  }
        //  if(key =='r'){

        //  console.log("this is r");
        radioResult = RadioboxFunction();
        //  console.log(radioResult);
        //  }

        // console.log("this is final array");
        var defaultresult = DefaultFunction();
        // console.log(defaultresult);
        const mergeResultFinal = [].concat(checkboxresult, radioResult, defaultresult);
        // console.log(mergeResultFinal);
        var priceonOFF = 0;
        var priceMonthy = 0;
        for (let i = 0; i < mergeResultFinal.length; i++) {
            let price = mergeResultFinal[i];
            if (!price.includes("Month")) {
                // console.log(price);
                // console.log("product price");
                var finalpriceofproduct = price.replace('$', '');
                priceonOFF = priceonOFF + parseInt(finalpriceofproduct);
                // console.log(priceonOFF);

            } else {
                //   console.log(i);
                //   console.log(price);
                let newproductprice_string_removed = RemoveStringCharacter_Regex(price);
                //   console.log(typeof(newproductprice_string_removed));

                priceMonthy = priceMonthy + parseInt(newproductprice_string_removed);
                //   console.log("incluuded");
            }

        }
        //   console.log("final price");
        //   console.log(priceonOFF);
        //   console.log(priceMonthy);


        var priceonOFFfinal = "<p style='font-size: 25px;'> One Time Price   $" + priceonOFF + ".00</p>";
        var priceMonthyfinal = "<p style='font-size: 25px;'> Monthly Price   $" + priceMonthy + ".00 </p>";

        $("#OnetimepriceAppend").html(priceonOFFfinal);
        $("#MonthlypriceAppend").html(priceMonthyfinal);

    }


    function RemoveStringCharacter_Regex(pricestring) {
        const regex = /[0-9-.]/gm;
        const str = pricestring;
        let m;
        let productPrice = '';
        while ((m = regex.exec(str)) !== null) {
            if (m.index === regex.lastIndex) {
                regex.lastIndex++;
            }

            m.forEach((match, groupIndex) = > {
                productPrice = productPrice + match;
        }
    )
        ;
    }
    return productPrice;
    }


    function CheckboxFunction() {
        // console.log("onchange checkbox");
        checkbox = $(".CalculatePriceCheckbox input[type='checkbox']:checked").map(function () {

            return this.parentElement.innerText;
        }).get();

        return checkbox;

    }


    // all radiobutton select type    

    function RadioboxFunction() {
        var Radiobox_items = $(".CalculatePriceRadio input[type='radio']:checked").map(function () {
            return this.parentNode.parentElement.innerText;
        }).get();

        return Radiobox_items;
    }

    function DefaultFunction() {
        var alldefault = $(".CalculatePricepreselected").map(function () {
            return this.innerText;
        }).get();
        return alldefault;
    }

    // all radiobutton select type

    function SelectRadioAfterclick(key, type) {
        // console.log(key);
        if (type == 'c') {
            // console.log("inside c")
            var newVal = "#" + key;
            if ($(newVal).prop('checked') == true) {
                $(newVal).prop('checked', false);
                $(newVal).parents().eq(2).css({"background-color": "white", "font-size": "200%"});
                mainFunctionTocalculateprice('c');
            } else {
                $(newVal).parents().eq(2).css({"font-size": "200%"});
                $(newVal).prop('checked', true);
                mainFunctionTocalculateprice('c');
            }
        }
        if (type == 'r') {
            //   console.log("inside r")
            var newVal = "#" + key;
            $(newVal).parents().eq(2).css({", "font-size": "200%"});
            $(newVal).prop("checked", true);
            var checked = $('input[type="radio"]:not(:checked)');
            for (let index = 0; index < checked.length; ++index) {

                let idhere = checked[index].id;
                var newVal = "#" + idhere;
                // 	  console.log(newVal);
                $(newVal).parents().eq(2).css({"background-color": "white", "font-size": "200%"});
            }

            mainFunctionTocalculateprice('r');
        }
        // console.log("button clicked");
    }


</script>

<script>
    $(document).ready(function () {


        let Link = window.location.pathname;
        const regex = /\/yourtemplate\//;
        const str = Link;
        const subst = ``;
        const result = str.replace(regex, subst);
        // console.log(result);
        $('#generatePdfLink').attr('href', '/GenerarePdf/' + result)

    });
</script>


<script>
    $(document).ready(() = > {
        var canvasDiv = document.getElementById('canvasDiv');
    var canvas = document.createElement('canvas');
    canvas.setAttribute('id', 'canvas');
    canvasDiv.appendChild(canvas);
    $("#canvas").attr('height', $("#canvasDiv").outerHeight());
    $("#canvas").attr('width', $("#canvasDiv").width());
    if (typeof G_vmlCanvasManager != 'undefined') {
        canvas = G_vmlCanvasManager.initElement(canvas);
    }

    context = canvas.getContext("2d");
    $('#canvas').mousedown(function (e) {
        var offset = $(this).offset()
        var mouseX = e.pageX - this.offsetLeft;
        var mouseY = e.pageY - this.offsetTop;

        paint = true;
        addClick(e.pageX - offset.left, e.pageY - offset.top);
        redraw();
    });

    $('#canvas').mousemove(function (e) {
        if (paint) {
            var offset = $(this).offset()
            //addClick(e.pageX - this.offsetLeft, e.pageY - this.offsetTop, true);
            addClick(e.pageX - offset.left, e.pageY - offset.top, true);
            console.log(e.pageX, offset.left, e.pageY, offset.top);
            redraw();
        }
    });

    $('#canvas').mouseup(function (e) {
        paint = false;
    });

    $('#canvas').mouseleave(function (e) {
        paint = false;
    });

    var clickX = new Array();
    var clickY = new Array();
    var clickDrag = new Array();
    var paint;

    function addClick(x, y, dragging) {
        clickX.push(x);
        clickY.push(y);
        clickDrag.push(dragging);
    }

    $("#reset-btn").click(function () {
        context.clearRect(0, 0, window.innerWidth, window.innerWidth);
        clickX = [];
        clickY = [];
        clickDrag = [];
    });

    $(document).on('click', '#btn-save', function () {
        var mycanvas = document.getElementById('canvas');
        var img = mycanvas.toDataURL("image/png");
        console.log(img);
        anchor = $("#signature");
        anchor.val(img);

    });

    var drawing = false;
    var mousePos = {
        x: 0,
        y: 0
    };
    var lastPos = mousePos;

    canvas.addEventListener("touchstart", function (e) {
        mousePos = getTouchPos(canvas, e);
        var touch = e.touches[0];
        var mouseEvent = new MouseEvent("mousedown", {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        canvas.dispatchEvent(mouseEvent);
    }, false);


    canvas.addEventListener("touchend", function (e) {
        var mouseEvent = new MouseEvent("mouseup", {});
        canvas.dispatchEvent(mouseEvent);
    }, false);


    canvas.addEventListener("touchmove", function (e) {

        var touch = e.touches[0];
        var offset = $('#canvas').offset();
        var mouseEvent = new MouseEvent("mousemove", {
            clientX: touch.clientX,
            clientY: touch.clientY
        });
        canvas.dispatchEvent(mouseEvent);
    }, false);


    // Get the position of a touch relative to the canvas
    function getTouchPos(canvasDiv, touchEvent) {
        var rect = canvasDiv.getBoundingClientRect();
        return {
            x: touchEvent.touches[0].clientX - rect.left,
            y: touchEvent.touches[0].clientY - rect.top
        };
    }


    var elem = document.getElementById("canvas");

    var defaultPrevent = function (e) {
        e.preventDefault();
    }
    elem.addEventListener("touchstart", defaultPrevent);
    elem.addEventListener("touchmove", defaultPrevent);


    function redraw() {
        //
        lastPos = mousePos;
        for (var i = 0; i < clickX.length; i++) {
            context.beginPath();
            if (clickDrag[i] && i) {
                context.moveTo(clickX[i - 1], clickY[i - 1]);
            } else {
                context.moveTo(clickX[i] - 1, clickY[i]);
            }
            context.lineTo(clickX[i], clickY[i]);
            context.closePath();
            context.stroke();
        }
    }
    })
</script>

<!-- next steps end -->

<div><br><br>

    <p style="font-size:12px;">
        Copyright by Code Conspirators, All Rights Reserved.
    </p>
</div>

</div>
</div>

</div>
</div>
</div>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.0/dist/alpine.min.js"></script>

<script src="https://files.codeconspirators.com/_resources/proposal/assets/js/theme.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</body>

</html>

</html>