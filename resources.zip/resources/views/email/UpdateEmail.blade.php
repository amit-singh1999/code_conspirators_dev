<table cellpadding="0" cellspacing="0" style="vertical-align: -webkit-baseline-middle; font-size: medium; font-family: Arial;">
<tbody>
<tr>
	<td>
		<p>Hi <?php echo $name ?>, thanks for being a Conspirator!&nbsp;&nbsp; </p>
	    <p>Your new project is added.Please login below to see the progress.&nbsp;</p>

		<p style="margin-left:20px;">Login at: <a href="https://portal.codeconspirators.com" style="color:#c72027;">portal.codeconspirators.com</a></p>
	    
	    <p>Thanks again for allowing us to partner with you!</p>
</td>
</tr>
</tbody>
</table>
<table cellpadding="0" cellspacing="0" style="vertical-align: -webkit-baseline-middle; font-size: medium; font-family: Arial;"><tbody>
	<tr>
		<td>
		</td>
	</tr>
	<tr>
      <td valign="top"><div style="width: 10px; height:10px;"></div></td>
      <td valign="top"><table cellpadding="0" cellspacing="0" class="sc-jDwBTQ dWtMUn" style="vertical-align: -webkit-baseline-top; font-size: medium; font-family: Arial;"><tbody>
            <tr>
              <td style="vertical-align: middle;"><div style="width: 30px; height:10px;"></div></td>
            </tr>
            <tr>
              <td valign="top" style="vertical-align: top; padding-top:5px; padding-right:10px;"><h3 color="#444444" class="sc-jhAzac hmXDXQ" style="margin: 0px; font-size: 18px; color: rgb(68, 68, 68);"><span>
                Codee</span></h3>
              <p color="#444444" font-size="medium" class="sc-fMiknA bxZCMx" style="margin: 0px; font-weight: 500; color: rgb(68, 68, 68); font-size: 14px; line-height: 22px;"><span></span></p></td>
            </tr>
            <tr>
              <td valign="top" style="vertical-align: top; padding-top:5px; padding-right:10px;"><div style="width: 1px; height:5px;"></div></td>
            </tr>
            <tr>
              <td valign="top" align="left" style="vertical-align: top; text-align: left; padding-top:5px; padding-right:10px;"><a href="https://codeconspirators.com" target="_blank"><img src="http://codeconspirators.com/wp-content/uploads/2019/10/logo-CC-horz-250.jpg" /></a></td>
            </tr>
            </tbody>
</table></td></tr></tbody></table>
<br />
<br />
