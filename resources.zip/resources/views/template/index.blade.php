@section('title', 'Proposal Template')
<div class="container-fluid mt--7" >
    <div class="row">
        <div class="col-xl-12 mb-5 mb-xl-0">
            <div class="card bg-gradient-default shadow" style="margin-bottom:6%">
                <div class="card-header bg-transparent">
                    <div class="row align-items-center">
                        <div class="col">
                            <h2><b>Templates</b></h2>
                            @if(Illuminate\Support\Facades\Auth::user()->role=="Admin")
                               <div class="container" style="margin-top:-10px">
                                <div class="row" style="float:right;margin-top: -17px">
                                    <a href="{{route('admin.create')}}">
                                        <i class="fa fa-plus" aria-hidden="true"></i>
                                    </a>
                                </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="chart">
                        <table class="table table-bordered table-responsive-lg">
                            <tr>
                                <th>Proposal Template</th>
                                 @if(Illuminate\Support\Facades\Auth::user()->role=="Admin")
                                 <th>Action</th>
                                 @endif
                            </tr>
                            <?php
                            for ($i = 0; $i < count($alltemplatedata); $i++) {  ?>
                                <tr>
                                    <td><?php echo $alltemplatedata[$i]['name'] ?></td>
                                     @if(Illuminate\Support\Facades\Auth::user()->role=="Admin")
                                    <th> <a href="{{ route('admin.edit', $alltemplatedata[$i]['id']) }}" class="link_color">
                                            <i class="fas fa-edit"></i>
                                                                                <a onclick="return confirm('Are you sure?')" href="{{route('admin.destroy',$alltemplatedata[$i]['id']) }}" class="link_color" ><i class="far fa-trash-alt"></i></a> </th>

                                       
                                    
                                    @endif

                                </tr>
                            <?php } ?>



                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>