<?php

// including file at top commenting for better undestanding
// require '../vendor/autoload.php';


namespace App\Http\Controllers;
 require '../vendor/quickbook/vendor/autoload.php';
 


use DB;
use Hash;
use Mail;

use App\Models\User;
use App\Models\Project;
use	App\Http\Controllers\Auth\MagicLoginController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

$user = Auth::user();
use QuickBooksOnline\API\DataService\DataService;
use QuickBooksOnline\API\Core\Http\Serialization\XmlObjectSerializer;
use QuickBooksOnline\API\Facades\Invoice;
use QuickBooksOnline\API\Core\OAuth\OAuth2\OAuth2LoginHelper;
use QuickBooksOnline\API\Core\OAuth\OAuth2\OAuth2AccessToken;



class ApiController extends Controller
{
    /* quick book method */
    
    /* for refreshing new token */
    public function getnewtoken($theRefreshTokenValue)
    {
        $response = array();
        $response['is_valid'] = true;
        $response['access_token'] = true;
        
        $ClientID = "ABIN35BGno09rFQygZdqQ0SGK9PyKuqto4TgTHsX00hzFfYHmk";
        $ClientSecret = "4WpN0wYggPfIMgkJpjRdtkFqQJnqzvtWt4IIfCUM";
        
        try{
            $oauth2LoginHelper = new OAuth2LoginHelper($ClientID,$ClientSecret);
            $accessTokenObj = $oauth2LoginHelper->refreshAccessTokenWithRefreshToken($theRefreshTokenValue);
            $accessTokenValue = $accessTokenObj->getAccessToken();
            $refreshTokenValue = $accessTokenObj->getRefreshToken();   
            $token = array();
            $token['access_token'] = $accessTokenValue;
            $token['refresh_token'] = $refreshTokenValue;
            $token['updated_at'] = date('Y-m-d H:i:sa');
            file_put_contents(storage_path()."/token.json",json_encode($token));
            $response['access_token'] = $accessTokenValue;
        }
        catch(\Exception $e){
            $response['is_valid'] = false;
            $response['access_token'] = false;
            $response['error_message'] = $e->getMessage();
        }
        
        return $response;
    }
    
  /* invoice ko fetch krta hai */
    
    public function quickbook_invoice_api()
    {
        
        $response = array();
        $response['is_valid']=false;
        $response['message']=false;
        $response['data']=false;
        
        $tokens = file_get_contents(storage_path()."/token.json");
        $tokens = json_decode($tokens,true);
        if(!isset($tokens['access_token'])){
            $response['message']="access token not found";
            return json_encode($response);
        }
        $refresh_token = $tokens['refresh_token'];
        $result = $this->getnewtoken($refresh_token);


        if($result['is_valid']==false)
        {
            $response['message']=$result['error_message'];
            $response['data']=false;
            return json_encode($response);   
        }
        
        $access_token = $result['access_token'];
        
        $user = Auth::user();
        $email = $user->email;
        
        try{
            $dataService = DataService::Configure(array(
                'auth_mode' => 'oauth2',
                'ClientID' => "ABIN35BGno09rFQygZdqQ0SGK9PyKuqto4TgTHsX00hzFfYHmk",
                'ClientSecret' => "4WpN0wYggPfIMgkJpjRdtkFqQJnqzvtWt4IIfCUM",
                'RedirectURI' => "https://portal-dev.codeconspirators.com/codeconspirators_dev_instance/argon/public/quickbook_callback",
                'scope' => "com.intuit.quickbooks.accounting",
                'baseUrl' => "production"
            ));
            $oathaccesstokenobj = new OAuth2AccessToken('ABIN35BGno09rFQygZdqQ0SGK9PyKuqto4TgTHsX00hzFfYHmk', '4WpN0wYggPfIMgkJpjRdtkFqQJnqzvtWt4IIfCUM',$access_token);
            // $oathaccesstokenobj->setRealmID("9130350810338796");
            
            $oathaccesstokenobj->setRealmID("380042956");
            
            $dataService->updateOAuth2Token($oathaccesstokenobj);
            
            $customer = $dataService->Query("Select * from Customer where PrimaryEmailAddr = '$email'");
            $customer_id=isset($customer[0]->Id)?$customer[0]->Id:0;
            if($customer_id)
            {
                $param = "select * from invoice  where CustomerRef ='$customer_id'";
                $allInvoices = json_decode($this->fetch_invoice($access_token,$param),true);
                $response['is_valid']=true;
                $response['message']=true;
                $response['data']=$allInvoices;
                return json_encode($response);
            }
            else
            {
                $response['message']="No Customer Found";
                return json_encode($response);
            }
        }
        catch(\Exception $e)
        {
            $response['message']="Quicbook Error";
            $response['data']=$e->message();
            return json_encode($response);
        }
    }
    public function fetch_invoice($access_token,$param)
    {
        
        $param = urlencode($param);
        $curl = curl_init();
       
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://quickbooks.api.intuit.com/v3/company/380042956/query?query=$param&include=InvoiceLink&minorversion=59",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Accept: application/json',
            'Authorization: Bearer '.$access_token
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        return $response;
        
     }
     
     
     //this method i will call from another controller to create invoice in quickbook
     public function quickbook_invoice_create_api($data,$req)
    {
    
        $response = array();
        $response['is_valid']=false;
        $response['message']=false;
        $response['data']=false;
        
        $tokens = file_get_contents(storage_path()."/token.json");
        $tokens = json_decode($tokens,true);
        if(!isset($tokens['access_token'])){
            $response['message']="access token not found";
            return json_encode($response);
        }
        
        $refresh_token = $tokens['refresh_token'];
        $result = $this->getnewtoken($refresh_token);
        if($result['is_valid']==false)
        {
            $response['message']=$result['error_message'];
            $response['data']=false;
            return json_encode($response);   
        }
        
        $access_token = $result['access_token'];
        $this->create_invoice_from_portal($access_token,$data,$req);
        return "hey";
        
    }

     //main function to create incoice
      public function create_invoice_from_portal($access_token,$data,$req){
              $resultfrombitrix=$data;
            //   echo "subal";
            //   dd($data);
          
              if(isset($data->CLIENT_EMAIL)){
                $email=$data->CLIENT_EMAIL;
                
                $response_from_handler= $this->quickbook_customer_handler($access_token,$email);
                $custome_existence_checking=json_decode($response_from_handler);
                $data=json_encode($custome_existence_checking->QueryResponse);
                $arr = (array)$data;
                if($arr[0]=='{}'){
                    
                    //agr phle se hai to dubara  create ni hoga
                    $customer_ref_id=$this->createCustomerInquickbOOk($resultfrombitrix,$access_token);
                    //crere a invoice
                    $this->createinvoice($resultfrombitrix,$customer_ref_id,$access_token,$req);
                }
                else{
                  //get id which is customer ref create invoice
                   $customerRef=$custome_existence_checking->QueryResponse->Customer[0]->Id;
                   $this->createinvoice($resultfrombitrix,$customerRef,$access_token,$req);
                   
                   //invoice created and we have to redirect from here
                   
                
                   
                   
                }
   

                // dd($custome_existence_checking->QueryResponse);
             
                
                
                //checking if this email is already customer or not
                 return redirect('/');
                
                dd("invoice created");
              }else{
                   
                 return redirect('/');
              }
              
             
           
     }
    
    //main function to create a customer
    public function createCustomerInquickbOOk($cutstomer_data,$access_token){
                $email=$cutstomer_data->CLIENT_EMAIL;
                $name='Mr'.$cutstomer_data->CLIENT_TITLE;
                $curl = curl_init();
                curl_setopt_array($curl, array(
                  CURLOPT_URL => 'https://quickbooks.api.intuit.com/v3/company/380042956/customer?minorversion=14',
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_POSTFIELDS =>'{
                    "BillAddr": {
                        "Line1": "123 Main Street",
                        "City": "Mountain View",
                        "Country": "USA",
                        "CountrySubDivisionCode": "CA",
                        "PostalCode": "94042"
                    },
                    "Notes": "Here are other details.",
                    "DisplayName": "'.$name.'",
                    "PrimaryPhone": {
                        "FreeFormNumber": "'.$cutstomer_data->CLIENT_PHONE.'"
                    },
                    "PrimaryEmailAddr": {
                        "Address": "'.$email.'"
                    }
                }
                ',
                  CURLOPT_HTTPHEADER => array(
                    'User-Agent: QBOV3-OAuth2-Postman-Collection',
                    'Accept: application/json',
                    'Content-Type: application/json',
                    'Authorization: Bearer '.$access_token,
                  ),
                ));
                $response = curl_exec($curl);
                curl_close($curl);
                $data=json_decode($response);
                return $data->Customer->Id;
    }
      //create invoice in quickbook
      public function createinvoice($data,$customerRef,$access_token,$req){
                $n=10;
               
       
          
                function getName($n) {
                	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                	$randomString = '';
                	for ($i = 0; $i < $n; $i++) {
                		$index = rand(0, strlen($characters) - 1);
                		$randomString .= $characters[$index];
                	}
                
                	return $randomString;
                }
                
                 $invoicenumberhere= (int)"custominvoice".getName($n);
               
    
                for($loopquick=0;$loopquick<count($req);$loopquick++){
        
                    $field_array['Line'][$loopquick] = array(
                    "Amount"=>$req[$loopquick]['PRODUCT_PRICE'],
                    "DetailType"=>"SalesItemLineDetail",
                    "SalesItemLineDetail"=>array(
                        "ItemRef"=>array(
                            "value"=>"1",
                            "name"=>"Services"
                        )
                    )    
                );
               
                }
        
              
              
                
                $field_array['BillEmail'] = array(                   
                    "Address"=>$data->CLIENT_EMAIL
                );
                // $field_array['ShipAddr'] = array(                   
                //      "City"=>"Middlefield", 
                //      "Line1"=>"5647 Cypress Hill Ave.", 
                //      "PostalCode"=>"94303", 
                //      "Lat"=>"37.4238562", 
                //      "Long"=>"-122.1141681", 
                //      "CountrySubDivisionCode"=>"CA"
                // );
                // $field_array['BillAddr'] = array(                   
                //     "Line4"=>"Middlefield, CA  94303", 
                //     "Line3"=>"5647 Cypress Hill Ave.", 
                //     "Line2"=>"Sonnenschein Family Store", 
                //     "Line1"=>"Russ Sonnenschein", 
                //     "Long"=>"-122.1141681", 
                //     "Lat"=>"37.4238562"
                // );
                $field_array['CustomerRef'] = array(                   
                     "value"=>$customerRef
                );
                
                $field_array['DocNumber']=$invoicenumberhere;
                
          
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://quickbooks.api.intuit.com/v3/company/380042956/invoice?minorversion=14',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => json_encode($field_array),
                CURLOPT_HTTPHEADER => array(
                    'User-Agent: QBOV3-OAuth2-Postman-Collection',
                    'Accept: application/json',
                    'Content-Type: application/json',
                    'Authorization: Bearer '.$access_token
                ),
            ));
            
            $response = curl_exec($curl);
            curl_close($curl);
        
     }
    
    
    public function testquickbook()
    {
        $tokens = file_get_contents(storage_path()."/token.json");
        $tokens = json_decode($tokens,true);
        if(isset($tokens['access_token']))
        {
            $access_token = $tokens['access_token'];
            $theRefreshTokenValue = $tokens['refresh_token'];
            $result = $this->getnewtoken($theRefreshTokenValue);
            
            if($result['is_valid'])
            {
                /* custom api */
                
            }
            else
            {
                echo $result['error_message'];
            }
        }
        else{
            /* execute only when admin is login */
            $is_valid = false;
            if($is_valid){
                $dataService = DataService::Configure(array(
                    'auth_mode' => 'oauth2',
                    'ClientID' => "ABIN35BGno09rFQygZdqQ0SGK9PyKuqto4TgTHsX00hzFfYHmk",
                    'ClientSecret' => "4WpN0wYggPfIMgkJpjRdtkFqQJnqzvtWt4IIfCUM",
                    'RedirectURI' => "https://portal-dev.codeconspirators.com/codeconspirators_dev_instance/argon/public/quickbook_callback",
                    'scope' => "com.intuit.quickbooks.accounting",
                    'baseUrl' => "production"
                ));
                $OAuth2LoginHelper = $dataService->getOAuth2LoginHelper();
                $authorizationCodeUrl = $OAuth2LoginHelper->getAuthorizationCodeURL();
                return redirect($authorizationCodeUrl);
            }
            echo "Access Denied";
        }
    }
    public function quickbook_callback()
    {
        if(!isset($_REQUEST["code"]) || !isset($_REQUEST["realmId"])) 
        {
            echo "Invalid Request.!";
            exit;
        }
        
        $code = $_REQUEST["code"];
        $id = $_REQUEST["realmId"];
        
        $dataService = DataService::Configure(array(
            'auth_mode' => 'oauth2',
            'ClientID' => "ABIN35BGno09rFQygZdqQ0SGK9PyKuqto4TgTHsX00hzFfYHmk",
            'ClientSecret' => "4WpN0wYggPfIMgkJpjRdtkFqQJnqzvtWt4IIfCUM",
            'RedirectURI' => "https://portal-dev.codeconspirators.com/codeconspirators_dev_instance/argon/public/quickbook_callback",
            'scope' => "com.intuit.quickbooks.accounting",
            'baseUrl' => "production"
        ));
        $OAuth2LoginHelper = $dataService->getOAuth2LoginHelper();
        
        $accessTokenObj = $OAuth2LoginHelper->exchangeAuthorizationCodeForToken($code,$id);
        $accessTokenValue = $accessTokenObj->getAccessToken();
        $refreshTokenValue = $accessTokenObj->getRefreshToken();
        
        $token = array();
        $token['access_token'] = $accessTokenValue;
        $token['refresh_token'] = $refreshTokenValue;
        $token['updated_at'] = date('Y-m-d H:i:sa');
        file_put_contents(storage_path()."/token.json",json_encode($token));
        echo "Access Token Saved.!";
    }
    
    public function quickbook_customer_handler($accesstoken,$email){
    //   $email="subalbro@gmail.com";
      $curl = curl_init();
      curl_setopt_array($curl, array(
      CURLOPT_URL => 'https://quickbooks.api.intuit.com/v3/company/380042956/query?minorversion=14',
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS =>"Select * from Customer  where PrimaryEmailAddr = '".$email."'",
      CURLOPT_HTTPHEADER => array(
        'User-Agent: QBOV3-OAuth2-Postman-Collection',
        'Accept: application/json',
        'Content-Type: application/text',
        'Authorization: Bearer ' .$accesstoken
      ),
      ));
    
      $response = curl_exec($curl);
      curl_close($curl);
      return $response;
    }
    
    
    public function api_dev(){
        \Artisan::call('route:cache');
        \Artisan::call('route:clear');
        \Artisan::call('config:cache');
        \Artisan::call('config:clear');
        \Artisan::call('key:generate');
        echo "true";
    }
    public function api(){
        $dir = storage_path().'/logs/test1.txt';
        file_put_contents($dir,json_encode($_REQUEST),FILE_APPEND|LOCK_EX);
        $taskId = json_encode($_REQUEST['data']['FIELDS_AFTER']['ID']);

//     $taskId = 98;
        //file_put_contents($dir,$taskId,FILE_APPEND|LOCK_EX);
            
            $curl = curl_init();
            
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://cc.codeconspirators.com/rest/13/kpylyymjqouoe0v2/task.item.getdata",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => '{"id":'.$taskId.'}',
              CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json",
                "postman-token: 115d2b95-729e-7604-005e-09628e9fd8e1"
              ),
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
            //  echo $response;
            }

        $task = json_decode($response);
        print_r($task);
        $title = $task->result->TITLE;
        if(strtolower($title)!="onboarding client"){
            echo 1;
            exit;
        }
        $group_id = $task->result->GROUP_ID;
        $cont_id = $task->result->UF_CRM_TASK[0];
        
        $cont_id= explode("_",$cont_id);
        $cont= $cont_id[1];
        echo $cont;
        //file_put_contents($dir,$cont,FILE_APPEND|LOCK_EX);
    
            $curl = curl_init();
            
            curl_setopt_array($curl, array(
              CURLOPT_URL => "https://cc.codeconspirators.com/rest/13/kpylyymjqouoe0v2/crm.contact.get",
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 30,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "POST",
              CURLOPT_POSTFIELDS => '{"id":"'.$cont.'"}',
              CURLOPT_HTTPHEADER => array(
                "cache-control: no-cache",
                "content-type: application/json",
                "postman-token: 99e38a00-0b0f-e39e-c8e4-db0991979076"
              ),
            ));
            
            $response = curl_exec($curl);
            $err = curl_error($curl);
            
            curl_close($curl);
            
            if ($err) {
              echo "cURL Error #:" . $err;
            } else {
            //  echo $response;
            }
            
            $cont_detail = json_decode($response);
            
            $name = $cont_detail->result->NAME;
            $email = $cont_detail->result->EMAIL[0]->VALUE; 
            echo $name ."". $email; 
            $password = randomPassword();
            echo $password;
        
          //  file_put_contents($dir,$name,FILE_APPEND|LOCK_EX);
            //file_put_contents($dir,$email,FILE_APPEND|LOCK_EX);
           // file_put_contents($dir,$password,FILE_APPEND|LOCK_EX);
        $user = User::where('email', $email)->first();
        $MagicLoginControllerhere = new MagicLoginController;
        $magiclinktoken =  $MagicLoginControllerhere->sendToken($email);
        // file_put_contents(storage_path()."/new.json",$magiclinktoken );
        $dir = storage_path().'/logs/test1.txt';
        file_put_contents($dir,"hell" );
        if (!$user) {
            $user = new User();
            $user->name = "sumit";
            $user->email = $email;
            $user->password = Hash::make($password);
            $user->save();
            
            
            $maildata = array('email' =>$email,'name'=>$name,'password'=>$password,'logintoken'=> $magiclinktoken);
        
        
            try{
            Mail::send('email.SendEmail',$maildata, function ($emailMessage) use ($maildata,$email){
                $emailMessage->subject('Welcome To CommandCenter!');
                $emailMessage->to($email);
            });
            }
            catch(\Exception $e){
                echo $e->getMessage();
            }
        }
        else{
            $maildata = array('email' =>$email,'name'=>$name,'password'=>$password,'logintoken'=> $magiclinktoken);
        
        
            try{
            Mail::send('email.UpdateEmail',$maildata, function ($emailMessage) use ($maildata,$email){
                $emailMessage->subject('Welcome To CommandCenter!');
                $emailMessage->to($email);
            });
            }
            catch(\Exception $e){
                echo $e->getMessage();
            }
        }

        // crete user project only once if already exist then dont create 
        $project = Project::Where([['user_id', '=', "$user->id"], ['project_id', '=', "$group_id"]])->first();
        if (!$project) {
            $project = new Project();
            $project->user_id = $user->id;
            $project->project_id = $group_id;
            $project->save();
        }
 
        
        
        
   
    }
}


function randomPassword() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    return implode($pass); //turn the array into a string
}

